# Responsive React Dashboard with Tailwind

A Pen created on CodePen.io. Original URL: [https://codepen.io/SH20RAJ/pen/RwOJNyb](https://codepen.io/SH20RAJ/pen/RwOJNyb).

Inspiration [Integration dashboard dark mode by  Alexey Savitskiy](https://dribbble.com/shots/14710948-Integration-dashboard-dark-mode)
                          
                      
This demo is also available on GitHub. [Here is the link](https://github.com/dilums/react-dashboard)
                          